/**
 * 
 */
/**
 * @author Jani Pasanen
 *
 */
package assignement1;